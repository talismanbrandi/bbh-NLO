#!/bin/sh
rm -f avh_olo.f90 avh_olo.o libavh_olo.* *.mod

/*   stdhep version common block */
extern struct stdver {
char stdhep_ver[10];      /* stdhep version numver */
char stdhep_date[20];     /* date of this stdhep version */
} stdver_;
